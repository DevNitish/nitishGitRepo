//refered from https://jsfiddle.net/toddmotto/xqauz9aa/?utm_source=website&utm_medium=embed&utm_campaign=xqauz9aa 
var app=angular.module('Todo', ['ngMaterial','ngMessages',"xeditable"])
  .controller('CountCtrl', function ($scope) {
    $scope.nitish = 007;
       $scope.mytasks = [
      {
        taskName: 'Task one',
        taskDetail: 'Do task one',
        status:true,
        startDate:'30-jul-2019',
        dueDate:'2018-06-22T05:41:02.182Z',
        image: 'https://latimesherocomplex.files.wordpress.com/2030/04/hughjackman4.jpg'
      },
      {
        taskName: 'task two',
        taskDetail: 'do task two',
        status:false,
        startDate:'30-jul-2017',
        dueDate:'2018-06-22T05:41:02.182Z',
        image: 'https://latimesherocomplex.files.wordpress.com/2030/04/hughjackman4.jpg'
      },
      {
        taskName: 'task three',
        taskDetail: 'do task three',
        status:true,
        startDate:'30-jul-2016',
        dueDate:'2018-06-22T05:41:02.182Z',
        image: 'https://pmcdeadline2.files.wordpress.com/2013/01/patrickheadshot.rt__130116211928.jpg'
      }
    ];
  })

        .component('counter', {
        bindings: {
          task: '<'
        },
        controller: countCtrl,
        templateUrl:'task.html'

    });

//end of angular

 app.run(function(editableOptions,editableThemes) {  editableOptions.theme = 'bs3';  
    
      editableThemes['bs3'].submitTpl='<button class="btn btn-danger"  type="submit" ng-click="updateTodoItem(listItem,todo)">Save</button><button class="btn btn-danger btn-circle" ng-click="addMemberToChecklist(listItem)">...</button>'; 
    // bootstrap3 theme. Can be also 'bs2', 'default'
    });

function countCtrl ($scope) {

  console.log("hello",this.task.dueDate);
   $scope.myDate = new Date(this.task.dueDate);
  $scope.minDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth() - 2,
      $scope.myDate.getDate());
  $scope.maxDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth() + 2,
      $scope.myDate.getDate());

          function increment() {
            this.count++;
          }
          function decrement() {
            this.count--;
          }
          this.increment = increment;
          this.decrement = decrement;
        }
//end of task










app.controller('myCtrl', function ($scope) {
  $scope.mytasks = [
    {
      taskName: 'Task 1',
      taskDetails: 'Do task one',
      status:true,
      image: 'https://latimesherocomplex.files.wordpress.com/2030/04/hughjackman4.jpg'
    },
    {
      taskName: 'task two',
      taskDetails: 'do task two',
      status:false,
      image: 'https://latimesherocomplex.files.wordpress.com/2030/04/hughjackman4.jpg'
    },
    {
      taskName: 'task three',
      taskDetails: 'do task three',
      status:true,
      image: 'https://pmcdeadline2.files.wordpress.com/2013/01/patrickheadshot.rt__130116211928.jpg'
    }
  ];
});
